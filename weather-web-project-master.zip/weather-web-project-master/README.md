![Screenshot (34)](https://github.com/tanavishali/weather-web-project/assets/110098816/91ed3e7e-7759-4bc5-b7a6-192f95279d83)
![Screenshot (33)](https://github.com/tanavishali/weather-web-project/assets/110098816/46112427-15a7-4171-92e4-ee5389459943)
![Screenshot (32)](https://github.com/tanavishali/weather-web-project/assets/110098816/2bd6906e-ed14-491e-95de-2ac36fbb9181)
